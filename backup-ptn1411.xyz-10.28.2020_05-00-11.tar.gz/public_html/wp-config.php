<?php
define( 'WP_CACHE', true );

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'umwFdRq2ZTOnnH' );

/** MySQL database username */
define( 'DB_USER', 'umwFdRq2ZTOnnH' );

/** MySQL database password */
define( 'DB_PASSWORD', '0XGdqcMMFjOmil' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'aF? cNtrHIBJZlt|csHlvoCT{i>_wP@C ve[*fOxr6p+rW3uNPwv6ejsKg0~ye)R' );
define( 'SECURE_AUTH_KEY',   '6vG$#e#H{k7R0o;2m$}~IcLdjwz2`-=_{=jkgK=}SO#mB=I2UA@{u%E:V#E,mi_(' );
define( 'LOGGED_IN_KEY',     '[k9H?3K}P8Co/ TLXs?a1cV^oG*zPh];)v5&_R9`)n^e96lC=rQLG14t5kj`5rdX' );
define( 'NONCE_KEY',         'o8;v8{CA8p%dU8o:LOXVr+Ye)!<N>:]KdEL<IdaDjC cu>|*J@Ii;PB4e]ce._vD' );
define( 'AUTH_SALT',         'D5Cf}/,P0?Pq}tCtf/RJ<T7VWgw*{(P8T] 0k%7[jMDXM%G8}dHc~KGC,o?UZ <%' );
define( 'SECURE_AUTH_SALT',  '|;TOL^Ec>EU6F]&lDl+@I-OkKDn22j/Ua206v.H@8#C%vd?fHIOs(dW*B>]y)Q_;' );
define( 'LOGGED_IN_SALT',    '&:,44A[$dg=-Z0[u$bQ6LwC(:?QyF&Au)yISu#kjEjiKuWa}JtV4/MLb0EIX[]o~' );
define( 'NONCE_SALT',        '~Q)sQmR9Ytmv>HwHD@_(#lAgAd#%#AGGuyRe::[f_O2ildiedhCOyRLfk;?<7w^D' );
define( 'WP_CACHE_KEY_SALT', '>)IKe<D0b)Jr%^X<]=1.@jsIA5~XRb_kP/c+E|<mko_NeNN{)pGUE:_Wdp>7<KkV' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
