<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- CSS only -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css" integrity="sha384-REHJTs1r2ErKBuJB0fCK99gCYsVjwxHrSU0N7I1zl9vZbggVJXRMsv/sLlOAGb4M" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.21/datatables.min.css" />
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<style>
    body {
        font-family: 'Roboto', serif !important;
    }
</style>

</style>
</head>

<body>
    <nav class="navbar navbar-expand-sm bg-primary navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="index.php">Pham Thanh Nam</a>

        <!-- Links -->
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link active" href="index.php">Xem sản phẩm</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">PP</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">TT</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-shopping-cart" style="font-size:25px;"></i> <span id="cart-item" class="badge badge-danger"></span></a>
            </li>
        </ul>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <h4 class="mt-2 text-primary">
                    Toàn bộ sản phẩm và giá.
                </h4>
            </div>
            <div class="col-lg-6">
                <button type="button" class="btn btn-primary m-1 float-right" data-toggle="modal" data-target="#addModal"><i class="fas fa-user-plus"></i>&nbsp;&nbsp; Thêm sản phẩm</button>
                <a href="action.php?export=excel" class="btn btn-success m-1 float-right"><i class="fas fa-table fa-lg"></i>&nbsp;&nbsp; Export to Excel</a>
            </div>
        </div>
        <hr class="my-1">
        <div class="row">
            <div class="w-100">
                <div class="table-responsive" id="showUser">
                    <div class="text-center">
                        <img src="preloader.gif" class="m-2" height="300" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- add new user -->
    <div class="modal fade" id="addModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Thêm sản phẩm</h4>
                    <button class="close" type="button" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body px-4">
                    <form action="" method="post" id="form-data">
                        <div class="form-group">
                            <input type="text" name="fname" class="form-control" placeholder="Tên sản phẩm" require>
                        </div>
                        <div class="form-group">
                            <input type="text" name="lname" class="form-control" placeholder="Giá sản phẩm" require>
                        </div>
                        <div class="form-group">
                            <input type="text" name="email" class="form-control" placeholder="Thời gian bảo hành" require>
                        </div>
                        <div class="form-group">
                            <input type="tel" name="phone" class="form-control" placeholder="Link sản phẩm" require>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="insert" id="insert" value="Add user" class="btn btn-danger btn-block">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- edit new user -->
    <div class="modal fade" id="editModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Sửa sản phẩm</h4>
                    <button class="close" type="button" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body px-4">
                    <form action="" method="post" id="edit-form-data">
                        <input type="hidden" name="id" id="id">
                        <div class="form-group">
                            <input type="text" name="fname" id="fname" class="form-control" id="fname" require>
                        </div>
                        <div class="form-group">
                            <input type="text" name="lname" class="form-control" id="lname" require>
                        </div>
                        <div class="form-group">
                            <input type="text" name="email" class="form-control" id="email" require>
                        </div>
                        <div class="form-group">
                            <input type="tel" name="phone" class="form-control" id="phone" require>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="update" id="update" value="Update" class="btn btn-danger btn-block">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.21/datatables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

   <script>
        $(document).ready(function() {

            showAllUsers();

            function showAllUsers() {
                $.ajax({
                    url: "action.php",
                    type: "POST",
                    data: {
                        action: "view"
                    },
                    success: function(response) {
                        $("#showUser").html(response);
                        $("table").DataTable({
                            order: [0, 'desc']
                        });
                    }
                });
            }
            $("#insert").click(function(e) {
                if ($("#form-data")[0].checkValidity()) {
                    e.preventDefault();
                    $.ajax({
                        url: "action.php",
                        type: "POST",
                        data: $("#form-data").serialize() + "&action=insert",
                        success: function(response) {
                            Swal.fire({
                                title: 'User add',
                                icon: 'success',
                            })
                            $("#addModal").modal('hide');
                            $("#form-data")[0].reset();
                            showAllUsers();
                        }
                    });
                }
            });
            $("body").on("click", ".editBtn", function(e) {
                e.preventDefault();
                edit_id = $(this).attr('id');
                $.ajax({
                    url: "action.php",
                    type: "POST",
                    data: {
                        edit_id: edit_id
                    },
                    success: function(response) {
                        data = JSON.parse(response);
                        $("#id").val(data.id);
                        $("#fname").val(data.first_name);
                        $("#lname").val(data.last_name);
                        $("#email").val(data.email);
                        $("#phone").val(data.phone);
                    }
                });
            });
            $("#update").click(function(e) {
                if ($("#edit-form-data")[0].checkValidity()) {
                    e.preventDefault();
                    $.ajax({
                        url: "action.php",
                        type: "POST",
                        data: $("#edit-form-data").serialize() + "&action=update",
                        success: function(response) {
                            Swal.fire({
                                title: 'User update',
                                icon: 'success',
                            })
                            $("#editModal").modal('hide');
                            $("#edit-form-data")[0].reset();
                            showAllUsers();
                        }
                    });
                }
            });
            $("body").on("click", ".delBtn", function(e) {
                e.preventDefault();
                var tr = $(this).closest('tr');
                del_id = $(this).attr('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        $.ajax({
                            url: "action.php",
                            type: "POST",
                            data: {
                                del_id: del_id
                            },
                            success: function(response) {
                                tr.css('background-color', '#ff6666');
                                Swal.fire(
                                    'Delete!',
                                    'User delete successfuly!',
                                    'success'
                                )
                                showAllUsers();
                            }
                        });
                    }

                });
            });
            $("body").on("click", ".infoBtn", function(e) {
                e.preventDefault();
                info_id = $(this).attr('id');
                $.ajax({
                    url: "action.php",
                    type: "POST",
                    data: {
                        info_id: info_id
                    },
                    success: function(response) {
                        data = JSON.parse(response);
                        Swal.fire({
                            title: '<strong> ID :' + data.id + ' </strong>',
                            icon: 'info',
                            html: '<b> Tên sản phẩm :</b>' + data.first_name + '<br><b>Giá sản phẩm :' + data.last_name + ' <b/><br><b>Thời gian bảo hành :</b>' + data.email + '<br><b>Linh sản phẩm :</b>' + data.phone + '<br>',
                            showCancelButton: true

                        })
                        showAllUsers();
                    }
                });
            });
        });
    </script>
</body>

</html>