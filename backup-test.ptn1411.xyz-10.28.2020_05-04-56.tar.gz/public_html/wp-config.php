<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'VJnTMYE0n8PaOt' );

/** MySQL database username */
define( 'DB_USER', 'VJnTMYE0n8PaOt' );

/** MySQL database password */
define( 'DB_PASSWORD', 'PrjAmsXhekpCkI' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'Aul./v[ao1v_3}K[]n3_=,y&wn6DWI{(NV^#)nAHk7O<-1N^x{?#mP<tL)`gfObM' );
define( 'SECURE_AUTH_KEY',   '}t>][3NfY5^Qrs@:/p!cf;ApbWI{|l1kXR.#k-2*Kb.KMj[W-u}bw!Yt#c2M!Q[F' );
define( 'LOGGED_IN_KEY',     'OY6IZC*0#9|w2dTXz95pGG:6,;rk`g]aDVvJ:WkrVV4}{G9y6;5:DNVF21F6ks>l' );
define( 'NONCE_KEY',         '9?99SQBNHGlHK%j7gxl<< Xs-uV*1!P83}N|aC-O6l}W}sQ}^zk<a3Kl.p(niojp' );
define( 'AUTH_SALT',         'K<(Y[Ca->iLtasn>x1`;|ePw~ FirI ]aq=0y*7}~YXm[UcLdOf2iwtMiS~[:6|o' );
define( 'SECURE_AUTH_SALT',  'BHn^)S+]Q#z}w(uV)4:TMl8G3&TsS0gr^5Z]GAv@P5BJk/8us[KR=&o!V^KX4wC(' );
define( 'LOGGED_IN_SALT',    '6$y[{}<UVBm@b~Yd{RM{mZA<LWo/7Sf7;YNV*w=n]7y]`bm{v-?Xm233GB~I*pn*' );
define( 'NONCE_SALT',        '#R||GJ:67b5uhLmvYjJ3x jV=6T$F:=uqxzT{Y?[g2XM>E,)QhPrPlfWD>|UidFb' );
define( 'WP_CACHE_KEY_SALT', 'qi=jq+5#B,s)BrpVk<+M @g<zEVumK(SXz4 Hh^a_]E]h1I;,q(nb|`HnbP#M(R=' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
