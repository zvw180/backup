<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'w45ZpNMSgbrZMR' );

/** MySQL database username */
define( 'DB_USER', 'w45ZpNMSgbrZMR' );

/** MySQL database password */
define( 'DB_PASSWORD', 'LGtMBYZazSK1PP' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'GNSLf>9hr%nK,C}uU{vp,~ml*-B-:FCV})uKW}$$z%9L2,mi!:7_h<^$(L%1%|(j' );
define( 'SECURE_AUTH_KEY',   ')Trx<+Q=n3F[ 2I9HRAWA<&}8z/0PYFt0xcK^>;buH1pO9bs[JLxof4dq$K9%w, ' );
define( 'LOGGED_IN_KEY',     'zp IHWx9uLObknmn42nY_nbAe5{::ccW7g!56z~OonHikAf|!Zr& A+{x!XcRZ,z' );
define( 'NONCE_KEY',         'HCZ?z9DbGJbTuX>+e?ey=TRoQ]VI$Tp+S.D9C,JNwBOo7>|%[Utj/FWIrM%Mdl}9' );
define( 'AUTH_SALT',         ' i7EW%N{Jq`s4fqm[[s5D/2oj#O/y|OFfp@D{pJQ33+V~eJ4>i#2yWh`IGgnPI+E' );
define( 'SECURE_AUTH_SALT',  '@eflMK6pOn3BHM&vB+%uR|rC=p%;e6[4RsDRWx[ sYKr@}cA6czW{.Rd!e/Q4Aw4' );
define( 'LOGGED_IN_SALT',    'b[(1z_pHau5X{nE/>N:peQ=5;{9jcB%sSo+  !Jl}FC*WZ/DjU&vG:wS%3w{pc>3' );
define( 'NONCE_SALT',        'Jm!s0:2iw2fM;?zQ`}(!xT4B<`IEMUZa8%{Y/IZe#F0*a^`ER&M*$!k6qN|g.),4' );
define( 'WP_CACHE_KEY_SALT', 'Y!z<Gx]?IR!(<F-|]NVqtyD2iI#]:CDoWxf<bo`FHp6KE[B#;Q~)63+AJxR>sNpt' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
