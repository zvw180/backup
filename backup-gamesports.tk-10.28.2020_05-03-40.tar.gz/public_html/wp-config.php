<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'ldgwwpPLNPVZaY' );

/** MySQL database username */
define( 'DB_USER', 'ldgwwpPLNPVZaY' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Ju6JuGCo3oBH5y' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'P{_~)m+(E_!xsS*4NU,U_tg3R}v,.~v )]0c_kkgJVm5tr~K!qcKZ{{D<S.cjk]5' );
define( 'SECURE_AUTH_KEY',   '7V+3&O}FxIOX5!,lfX+V^1/*A|TZy^ST~3KpZQyyY1{},g@`n-qXuj4SfSW90gwl' );
define( 'LOGGED_IN_KEY',     'Z:SAfh(=82?A*j/|@[=umy1)F]e&Yk<F>/YA4q{7`q?p6G0Lf9buEA&fWuKT^BIX' );
define( 'NONCE_KEY',         '4dRA?[bsI(13*XQ<uGzLB(bV8),XD4fW=^a`i5&pW3> 7l/iw8V/Tg`}Y^dk$i^_' );
define( 'AUTH_SALT',         '10i,XIx<^f/UH<OCrM9*v6!4iddw+z$ouszm0/injPhXz>6t3[Uuoe+{E.t%VV]o' );
define( 'SECURE_AUTH_SALT',  '/xv_.#sHYvRiHy;TC;.9?.e[%D=h&m86`1$DLz4f/Q<?y>1}zDDKv?URjXmYI>Eu' );
define( 'LOGGED_IN_SALT',    '[NBK&?6*#?M$v}yR~tDZ(elX~8(Z!X?NA=}f{-@yM_TiM$Imi^Dh<`0^Kd_D$4-]' );
define( 'NONCE_SALT',        ']<R@ozJ|.23MZomhE`t&vlfzdcT ZG_[Y9s:pMv3y|,g E7Ubv Qzxfd -;kaHAO' );
define( 'WP_CACHE_KEY_SALT', '$xfUsDP?krIVIMJlNjqO #v1esf3b!Q;piL=qWBFFz:p=oVX9UZ}NpEdft>2jWu+' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
