<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'Bbgu3AK7SYQ9zA' );

/** MySQL database username */
define( 'DB_USER', 'Bbgu3AK7SYQ9zA' );

/** MySQL database password */
define( 'DB_PASSWORD', 'IS5lqgDqGNhM6v' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '{|G<uoH`vhXeXc^O$w_]I@&dAW,Z,q0TCfawc(89y1)_m^o9G8w~ywI<~KV<ZaRn' );
define( 'SECURE_AUTH_KEY',   '9P5Nb#-s_gekUn[=p>ER!A}_I;pc!t:o$Tkm]98;qTy&]eA1_`ldq?+5gtl8$a%V' );
define( 'LOGGED_IN_KEY',     'O){U(=J~Mc|[ ^.0x%t]/Ad~1-];4?}EaS#-sp#5uwtTjXPDJZGeI(lg]Th#%,xJ' );
define( 'NONCE_KEY',         '0K&i9J|w``wiGy6bXpiTk<3&u0DRmwME8D=,M#u1C;4Mv}?(xN^ta:bwG 9Z+qyu' );
define( 'AUTH_SALT',         'r4S{BxA  /1]n:vEg!nA)|G+&7A)aD,W3u$|s$gb?!f0^n[H^`(e<;=Dvvo7^skv' );
define( 'SECURE_AUTH_SALT',  '.5>!tQ$DT}OB9sl?@.Oqn>|l^74zGY r!lwXCt1+hxs8](2{[R_(K/JHJ4Hgk2/f' );
define( 'LOGGED_IN_SALT',    '^w]]WBm-XR:8^|kHpL`OrY@G=Y ?ce+4%ivGwYVnui*|n^H7gh!gxktG:+h|z>})' );
define( 'NONCE_SALT',        'n0W{Hr&dS#v$>rjjA>YQR7|a8D##m;50H@T1L&EofDMR5_$?uPW]+hXi@iac]^U9' );
define( 'WP_CACHE_KEY_SALT', '}%Cm^PLBd?/zO_MPb<`UF}Ryulq9n>PF%+@&ozX<Avbs)AvE#Ag)>Pwi4rFF>N`X' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
