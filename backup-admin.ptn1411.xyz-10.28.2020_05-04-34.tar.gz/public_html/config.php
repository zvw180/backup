<?php
$dbhost = "localhost";
$dbuser = "admin_admin";
$dbpass = "5Cy@su*+gO!KIq%c";
$dbname = "admin_admin"; 

$conn = new mysqli($dbhost,$dbuser,$dbpass,$dbname);

if($conn->connect_error){
    die("Could not connect to the database".$conn->connect_error);
}
?>