<?php
require 'config.php';
$msg = "";
if (isset($_POST['submit'])) {
    $token = $_POST['token'];
    $newpass = sha1($_POST['newpass']);
    $cnewpass = sha1($_POST['cnewpass']);

    $stmt = $conn->prepare("SELECT id FROM users WHERE token=? AND tokenExpire>NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        if ($newpass == $cnewpass) {
            $stmt_u = $conn->prepare("UPDATE users SET pass=?");
            $stmt_u->bind_param("s", $newpass);
            $stmt_u->execute();
            $msg = "Password changed successfully! <br> <a href='index.php'>Login Here </a>";
        } else {
            $msg = "Password did not match!";
        }
    } else {
        $msg = "Code did not match!";
    }
}



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 mt-5">
                <h3 class="text-center bg-dark text-light p-2 rounded"> Reset your password here!</h3>
                <h4 class="text-success text-center">
                    <?= $msg; ?>
                </h4>
                <form action="" method="post">
                    <div class="form-group">
                        <label for="password"> Enter new password</label>
                        <input type="password" name="newpass" class="form-control" placeholder="New password" required>
                    </div>
                    <div class="form-group">
                        <label for="password"> Confirm new password</label>
                        <input type="password" name="cnewpass" class="form-control" placeholder="Confirm password" required>
                    </div>
                    <div class="form-group mx-sm-3 mb-2">
                        <input type="text" name="token" class="form-control" placeholder="Code" minlength="6">
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" value="Reset" class="btn btn-success btn-block">
                    </div>

                </form>

            </div>

        </div>
    </div>
</body>

</html>