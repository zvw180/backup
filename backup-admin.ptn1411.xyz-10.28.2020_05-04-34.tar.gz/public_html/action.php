<?php
require 'config.php';

if (isset($_POST['action']) && $_POST['action'] == 'register') {
    $name = check_input($_POST['name']);
    $uname = check_input($_POST['uname']);
    $email = check_input($_POST['email']);
    $pass = check_input($_POST['pass']);
    $cpass = check_input($_POST['cpass']);
    $pass = sha1($pass);
    $cpass = sha1($cpass);
    $created = date('Y-m-d');

    if ($pass != $cpass) {
        echo 'Password did not matched!';
        exit();
    } else {
        $sql = $conn->prepare("SELECT username,email FROM users WHERE username=? OR email=?");
        $sql->bind_param("ss", $uname, $email);
        $sql->execute();
        $result = $sql->get_result();
        $row = $result->fetch_array(MYSQLI_ASSOC);

        if ($row['username'] == $uname) {
            echo 'Username not available try different!';
        } elseif ($row['email'] == $email) {
            echo 'Email is already registered try different!';
        } else {
            $stmt = $conn->prepare("INSERT INTO users (name,username,email,pass,created) VALUES (?,?,?,?,?)");
            $stmt->bind_param("sssss", $name, $uname, $email, $pass, $created);
            if ($stmt->execute()) {
                echo 'Registered successfully. Login Now!';
            } else {
                echo 'Something went wrong. Please try again!';
            }
        }
    }
}

if (isset($_POST['action']) && $_POST['action'] == 'login') {
    session_start();
    $username = $_POST['username'];
    $password = sha1($_POST['password']);

    $stmt_l = $conn->prepare("SELECT * FROM users WHERE username=? AND pass=? ");
    $stmt_l->bind_param("ss", $username, $password);
    $stmt_l->execute();
    $user = $stmt_l->fetch();

    if ($user != null) {
        $_SESSION['username'] = $username;
        echo 'ok';

        if (!empty($_POST['rem'])) {
            setcookie("username", $_POST['username'], time() + (10 * 365 * 24 * 60 * 60));
            setcookie("password", $_POST['password'], time() + (10 * 365 * 24 * 60 * 60));
        } else {
            if (isset($_COOKIE['username'])) {
                setcookie("username", "");
            }
            if (isset($_COOKIE['password'])) {
                setcookie("password", "");
            }
        }
    } else {
        echo 'Login failed! check your username and password';
    }
}
if (isset($_POST['action']) && $_POST['action'] == 'forgot') {

    $femail = $_POST['femail'];

    $stmt_p = $conn->prepare("SELECT id FROM users WHERE email=?");
    $stmt_p->bind_param("s", $femail);
    $stmt_p->execute();
    $res = $stmt_p->get_result();

    if ($res->num_rows > 0) {
        $token = "1234567890";
        $token = str_shuffle($token);
        $token = substr($token, 0,6);

        $stmt_i = $conn->prepare("UPDATE users SET token=?, tokenExpire=DATE_ADD(NOW(), INTERVAL 5 MINUTE) WHERE email=?");
        $stmt_i->bind_param("ss", $token, $femail);
        $stmt_i->execute();

        require 'phpmailer/PHPMailerAutoload.php';

        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;

        $mail->SMTPAuth = true;
        $mail->SMTPSecure = 'tls';

        $mail->Username = 'phamthanhnamdev@gmail.com';
        $mail->Password = '3fa96cb18754f267';

        $mail->addAddress($femail);
        $mail->setFrom('phamthanhnamdev@gmail.com', 'Pham Thanh Nam');
        $mail->Subject = 'Reset password';
        $mail->isHTML(true);

        $mail->Body = "<h3>Code the reset password.</h3><br>Code : $token";

        if ($mail->send()) {
            echo 'We have send you the reset code in your email ID, please checck your email.';
        } else {
            echo 'Something went wrong please try later.';
        }
    }
}

if (isset($_GET['deleteu'])) {
    $id = $_GET['deleteu'];
    $query = "DELETE FROM users WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $id);
    $stmt->execute();

    header('location:profile.php');
}
function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
$update = false;
$id = "";
$web = "";
$name = "";
$email = "";
$password = "";
$photo = "";

if (isset($_POST['add'])) {
    $web = $_POST['web'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $photo = $_FILES['image']['name'];
    $upload = "uploads/" . $photo;

    $query = "INSERT INTO crud(web,name,email,password,photo) VALUES(?,?,?,?,?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", $web, $name, $email, $password, $upload);
    $stmt->execute();
    move_uploaded_file($_FILES['image']['tmp_name'], $upload);

    header('location:password.php');
}
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $web = $row['web'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $oldimage = $_POST['oldimage'];
    if (isset($_FILES['image']['name']) && ($_FILES['image']['name'] != "")) {
        $newimage = "uploads/" . $_FILES['image']['name'];
        unlink($oldimage);
        move_uploaded_file($_FILES['image']['tmp_name'], $newimage);
    } else {
        $newimage = $oldimage;
    }
    $query = "UPDATE crud SET name=?,email=?,password=?,photo=? WHERE id=? ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssi", $name, $email, $password, $newimage, $id);
    $stmt->execute();

    header('location:password.php');
}
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "SELECT photo FROM crud WHERE id=?";
    $stmt2 = $conn->prepare($sql);
    $stmt2->bind_param("i", $id);
    $stmt2->execute();
    $result2 = $stmt2->get_result();
    $row = $result2->fetch_assoc();

    $imagepath = $row['photo'];
    unlink($imagepath);

    $query = "DELETE FROM crud WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header('location:password.php');
}
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];

    $query = "SELECT * FROM crud WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $id = $row['id'];
    $web = $row['web'];
    $name = $row['name'];
    $email = $row['email'];
    $password = $row['password'];
    $photo = $row['photo'];

    $update = true;
}
?>
