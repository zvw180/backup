<?php
require 'session.php';
require 'action.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <script src="assets/js/jquery-3.5.1.js"></script>
    <script src="assets/js/jquery-3.5.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="md5.js"></script>
</head>

<body>
    <nav class="navbar navbar-expand-sm bg-primary navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">Pham Thanh Nam</a>

        <!-- Links -->
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="password.php">Password</a>
            </li>

            <!-- Dropdown -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                    <?= $username; ?>
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Setting</a>
                    <a class="dropdown-item" href="logout.php">Logout</a>

                </div>
            </li>
        </ul>
    </nav>

    <div>

        <form action="action.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $id; ?>">
            <div class="form-group">
                <input type="text" name="web" placeholder="Website" value="<?= $web; ?>" class="form-control">
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <input type="text" name="name" placeholder="Users" value="<?= $name; ?>" class="form-control">
                </div>
                <div class="form-group col-md-6">
                    <input type="tel" name="password" id="result" placeholder="Password" value="<?= $password; ?>" class="form-control">
                </div>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" value="<?= $email; ?>" class="form-control">
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <textarea rows="1" class="form-control" id="input"></textarea>

                </div>
                <div class="form-group col-md-6">
                    <button type="submit" id="calculate" class="btn btn-primary" onclick="result.value=md5(input.value);return false">
                        Password
                    </button>
                    <button type="reset" id="reset" class="btn btn-primary">Reset</button>
                </div>
            </div>
            <div class="form-group">
                <input type="hidden" name="oldimage" value="<?= $photo; ?>">
                <input type="file" name="image" class="custom-file">
                <img src="<?= $photo; ?>" width="120" class="img-thumbnail">
            </div>
            <div class="form-group">
                <?php if ($update == true) { ?>
                    <input type="submit" name="update" value="Update Record" class="btn btn-success">
                <?php } else { ?>
                    <input type="submit" name="add" value="Add Record" class="btn btn-primary">
                <?php } ?>

            </div>
        </form>


    </div>
    <div class="col-md-12">
        <?php
        $query = "SELECT * FROM crud";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();
        ?>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Link Website</th>
                    <th>Users</th>
                    <th>Email</th>
                    <th>Password</th>

                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = $result->fetch_assoc()) {
                ?>
                    <tr>
                        <td><?= $row['id']; ?></td>
                        <td> <img src="<?= $row['photo']; ?>" width="25"></td>
                        <td><?= $row['web']; ?></td>
                        <td><?= $row['name']; ?></td>
                        <td><?= $row['email']; ?></td>
                        <td><?= $row['password']; ?></td>
                        <td>
                            <button class="btn btn-warning btn-copy">Copy</button>
                            <a href="action.php?delete=<?= $row['id']; ?>" class="badge badge-danger p-2" onclick="return confirm('Do you want delete this record');"> Delete</a>
                            <a href="password.php?edit=<?= $row['id']; ?>" class="badge badge-success p-2"> Edit</a>
                            <a href="<?= $row['web']; ?>" class="badge badge-primary p-2">Link</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <script>
        $('.btn-copy').on('click', function() {
            element = $(this).closest('td').prev('td')[0];
            var selection = window.getSelection();
            var range = document.createRange();
            range.selectNodeContents(element);
            selection.removeAllRanges();
            selection.addRange(range);
            //Losely basd on http://stackoverflow.com/a/40734974/7668911
            try {
                var successful = document.execCommand('copy');
                if (successful) {
                    $('.res').html("Coppied");
                } else {
                    $('.res').html("Unable to copy!");
                }
            } catch (err) {
                $('.res').html(err);
            }
        });
    </script>
</body>

</html>