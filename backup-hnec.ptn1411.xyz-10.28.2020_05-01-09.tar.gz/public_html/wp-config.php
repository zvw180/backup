<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'Wp0Ig3vPbV0NBz' );

/** MySQL database username */
define( 'DB_USER', 'Wp0Ig3vPbV0NBz' );

/** MySQL database password */
define( 'DB_PASSWORD', 'LxIdFqAF7o9unf' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '~+dBSKra!L&M-K]K`.~. >t7:zLMz>[1qdBM/QwFvDRrZ-]bF0x.gMxmHD[#9cfH' );
define( 'SECURE_AUTH_KEY',   '8XY,AQ{8w/tc;rOI%MMOBl*g bFtg26|mjrB&=(q!-zJ52rE5Nsy?aHXJq&p8?wh' );
define( 'LOGGED_IN_KEY',     'q~S^Fgdvr<j~iH9<TM;Yu!_.TPY2QWyj{cKx{1BN4Ps|d8I ^~8!Z;pNI*v_OJ}_' );
define( 'NONCE_KEY',         'k$cHNhcv?eJ/@pUiD.g/&#g7,E}iA#C_cS<.s:ML+[C[zDYcRycNm8%i!5C,; Fr' );
define( 'AUTH_SALT',         '5eo+4NzWFXDa`(,R4p< {Vcdd&$fGLZQ_ENKlsxXfk{8_)_9g%,7TGU*&!s,$[|j' );
define( 'SECURE_AUTH_SALT',  '=8mOtH,{bF>;fO0~Mc/{)w.H5s_(^c^P0okRe3?IHJS3x6sS@>nEY&eHm8Myg4]Z' );
define( 'LOGGED_IN_SALT',    'DR.>!C#rFTzh<+~Uy@*)ZMZX4=-(b=i/K(& APm~foL>yyTT7)lY7}F[,D{&{$w ' );
define( 'NONCE_SALT',        'fMXfk(mG+jtxN^33V:V[)j{@UOc_Gb 0/v9glm/Wf-F3BkX#j6c%w#5lPky_>`<8' );
define( 'WP_CACHE_KEY_SALT', 'j1#fdD 8h$fn PB?0&a7Cc>:9S5VLrt.BR;1]1,$=`hmY+LMn5w[e/E4[,vK`g>0' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
