<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '3jZ2GEjfu5BkhB' );

/** MySQL database username */
define( 'DB_USER', '3jZ2GEjfu5BkhB' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Apn6HWp0Ig3vPb' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '0ad5I[r)o3T=cg;&j$$&*3/1;#NVm@q[AQDDB3#<o(glpAtrOCL%4`M#7wt c6mo' );
define( 'SECURE_AUTH_KEY',   'X:PNa.5d0g#Wu~D%:)dr _D _nESY(BYM~Gwlo>KD<:KTp5 +TwR_W/q_q*L=;,$' );
define( 'LOGGED_IN_KEY',     'S78)qgQCbBfr V6W@%%/,ZisP:~]jkJ7`:NL]HXp7wU]R6mmv2UR-;aKxJ@3&CIX' );
define( 'NONCE_KEY',         'o8rW?TM%36d@N9Q`yyx.0D#Q%1+lCMLDS)1rs-<TgCm3ejWS6/|7ZN6&Q#>1Mudj' );
define( 'AUTH_SALT',         'Lh?Z}[hdp0*/DfHusC 7|p?Bm4<y*-cIQ eJ1;a_WUmsX+2qYkI0AzUi1{E6p2B!' );
define( 'SECURE_AUTH_SALT',  'jP?km/V8e!m V,39X}By0Cq`[5C=V>gyUkq<~>iiF;E.yFy97tIjxNlAhxy1RsJd' );
define( 'LOGGED_IN_SALT',    'mB@5le!V{pvj*CB)_cPT=,`hfEYmWy7z673b*hp4X`u|_].`7KsW4`erkhT1$zS ' );
define( 'NONCE_SALT',        'TPUR3<=mm{B}IXdk.Wt)-v%.-A)4a6pL>7E>`yu*/ EDzVSOyP%f.&S{azsBH|+g' );
define( 'WP_CACHE_KEY_SALT', 'Aq:MyU1Ho/|JAjQcbR6B.@.}l0wdAE%=GSX7]# JzxQ=V_`LS67oll)<Nm(4%|Vk' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
